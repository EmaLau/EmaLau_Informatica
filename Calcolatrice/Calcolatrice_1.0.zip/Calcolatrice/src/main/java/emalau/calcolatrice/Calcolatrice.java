package emalau.calcolatrice;

public class Calcolatrice {

    public static void main(String[] args) {
        Calcolatrice_GUI Calc_GUI = new Calcolatrice_GUI();
        Calc_GUI.setVisible(true);
    }
}
